# Import necessary libraries
import pickle
import pandas as pd

# Create an instance of the DecisionTreeModel class
model = DecisionTreeModel()

# Load your data using the load function
file_path = "/content/historic.csv"  # Replace this with the path to your historic data
model.load(file_path)

# Preprocess the data
model.preprocess()

# Train the model
model.train()

# Test the model
model.test()

# Save the model as a pickle file
with open("decision_tree_model.pkl", "wb") as f:
    pickle.dump(model, f)

# Load the prediction data
prediction_data = pd.read_csv("/content/prediction_input.csv")

# Preprocess the prediction data
prediction_data = pd.get_dummies(prediction_data, columns=['category', 'main_promotion', 'color'])

# Make predictions
predictions = model.predict(prediction_data)

# Display the predictions
print("Predictions on prediction_input.csv:")
print(predictions)

