# model_ann.py

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

class ANNModel:
    def __init__(self):
        self.model = MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=1000)
    
    def load(self, file_path):
        self.data = pd.read_csv(file_path)
    
    def preprocess(self):
        # Perform label encoding for target variable
        label_encoder = LabelEncoder()
        self.data['success_indicator'] = label_encoder.fit_transform(self.data['success_indicator'])
        
        # Perform one-hot encoding for categorical variables
        categorical_cols = ['category', 'main_promotion', 'color']
        self.data = pd.get_dummies(self.data, columns=categorical_cols)
    
    def train(self):
        X = self.data.drop(columns=['success_indicator'])
        y = self.data['success_indicator']
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model.fit(self.X_train, self.y_train)
    
    def test(self):
        y_pred = self.model.predict(self.X_test)
        accuracy = accuracy_score(self.y_test, y_pred)
        precision = precision_score(self.y_test, y_pred, pos_label=1)  # Adjust pos_label according to your label encoding
        recall = recall_score(self.y_test, y_pred, pos_label=1)  # Adjust pos_label according to your label encoding
        f1 = f1_score(self.y_test, y_pred, pos_label=1)  # Adjust pos_label according to your label encoding
        cm = confusion_matrix(self.y_test, y_pred)
        
        print(f"ANN Model Evaluation Results:")
        print(f"Accuracy: {accuracy}")
        print(f"Precision: {precision}")
        print(f"Recall: {recall}")
        print(f"F1 Score: {f1}")
        print("Confusion Matrix:")
        print(cm)
    
    def predict(self, new_data):
        # Perform the same preprocessing steps for new data
        new_data['success_indicator'] = label_encoder.transform(new_data['success_indicator'])
        new_data = pd.get_dummies(new_data, columns=['category', 'main_promotion', 'color'])
        predictions = self.model.predict(new_data)
        return predictions

# Create an instance of the ANNModel class
model = ANNModel()

# Load your data using the load function
file_path = "/content/historic.csv"  # Replace this with the path to your data
model.load(file_path)



# Preprocess the data (if necessary)
model.preprocess()

# Train the model
model.train()

# Test the model and display the evaluation results
model.test()

